# 📚 Library Management Database - Task 1

## 📝 Objective
To design a relational database schema for a Library Management System using SQL and create an ER diagram to visualize entity relationships.

## 🔧 Tools Used
- MySQL Workbench (for SQL execution & ER diagram)
- GitHub (for submission)
- Markdown (for documentation)

## 🗃️ Entities and Relationships

- **Author**: Stores author details.
- **Book**: Stores book information.
- **Book_Author**: Represents many-to-many relation between books and authors.
- **Member**: Stores member details.
- **BorrowingRecord**: Tracks which member borrowed which book and when.

## 🔗 Relationships
- One-to-Many: Member ↔ BorrowingRecord
- Many-to-Many: Book ↔ Author

## 📂 Files Included
- `schema.sql`: SQL file to create database and tables.
- `README.md`: You are reading it 😊

## 🧪 How to Run
1. Open MySQL Workbench
2. Copy contents of `schema.sql` into a new SQL tab
3. Execute the script
4. Use “Reverse Engineer” in Workbench to generate ER diagram

## 📌 Concepts Covered
- DDL (CREATE, PRIMARY KEY, FOREIGN KEY)
- Normalization (3NF)
- Constraints (`UNIQUE`, `NOT NULL`)
- Surrogate Keys (`AUTO_INCREMENT`)
- ER Diagrams

---

Made with ❤️ for Task 1 submission.
